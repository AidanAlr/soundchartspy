# sounchartspy
A python wrapper for the [Soundcharts API](https://www.soundcharts.com/api/docs).
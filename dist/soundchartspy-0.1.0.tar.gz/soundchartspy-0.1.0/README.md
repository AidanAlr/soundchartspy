# Sounchartspy
A python wrapper for the [Soundcharts API](https://www.soundcharts.com/api/docs).

## Installation
```bash
pip install soundchartspy
```
## Usage
```python
from soundchartspy import Soundcharts
sc = Soundcharts(api_key='your_api_key', app_id='your_app_id')
song = sc.get_song_metadata_from_uuid('song_uuid')

print(song.get_name())
print(song.get_main_artist_name())
print(song.get_release_date())
```